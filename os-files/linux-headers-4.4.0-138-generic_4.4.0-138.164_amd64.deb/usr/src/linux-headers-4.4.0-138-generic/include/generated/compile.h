/* This file is auto generated, version 164 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#164 SMP Wed Nov 7 11:16:43 EST 2018"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "N111471-03"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.10) "
